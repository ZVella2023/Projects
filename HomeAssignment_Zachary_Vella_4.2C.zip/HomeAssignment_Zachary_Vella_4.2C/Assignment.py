import numpy as np
from imutils.video import VideoStream
from PIL import Image
from tkinter import *
import matplotlib.pyplot as plt
import cv2

# Update button
def click1():
    print("Button1")
    import cv2
    import os
    # Call the built-in camera of the notebook, so the parameter is 0. If there are other cameras, you can adjust the parameter to 1, 2

    cap = cv2.VideoCapture(0)
    # Cascade classifier is a cascaded classifier for face detection in Opencv
    face_detector = cv2.CascadeClassifier('Models/haarcascade_frontalface_default.xml')

    face_id = input('\n enter user name:')

    print('\n Initializing face capture. Look at the camera and wait ...')

    count = 0

    while True:

        # Read pictures from camera

        sucess, img = cap.read()

        # Turn to grayscale picture

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Face detection

        faces = face_detector.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + w), (255, 0, 0))
            count += 1

            # Save image
            cv2.imwrite("images/" + str(face_id) + '.' + str(count) + '.jpg', gray[y: y + h, x: x + w])

            cv2.imshow('image', img)

        # Keep the picture going.

        k = cv2.waitKey(1)

        if k == 27:  # Exit camera by esc key
            break

        elif count == 55:  # Get 1000 samples and exit the camera
            break

    # Turn off camera
    cap.release()
    cv2.destroyAllWindows()

#Access button
def click2():
        print("Button2")
        import face_recognition
        import cv2
        import numpy as np
        import math
        import os
        import smtplib

        def nothing(x):
            pass

        video_capture = cv2.VideoCapture(0)

        cv2.namedWindow("Video")
        cv2.createTrackbar("test", "Video", 0, 100, nothing)

        known_face_encodings = [

        ]
        known_face_names = [

        ]

        rootdir = 'E:\Mcast folder\Level 4.2\Projects\pythonProject\images'
        for subdir, dirs, files in os.walk(rootdir):
            for file in files:
                print(os.path.join(subdir, file))
                image = face_recognition.load_image_file(os.path.join(subdir, file))
                face_encoding = face_recognition.face_encodings(image)
                if len(face_encoding) > 0:
                    known_face_encodings.append(face_encoding[0])
                    known_face_names.append(file)

        # Initialize some variables
        face_locations = []
        face_encodings = []
        face_names = []
        process_this_frame = True

        while True:
            # Grab a single frame of video
            ret, frame = video_capture.read()

            test = cv2.getTrackbarPos("test", "Video")

            alpha = 2
            beta = 50

            if test == 0:
                pass
            else:
                frame = cv2.blur(frame, (test, test))

            cv2.imshow("Video", frame)

            # Resize frame of video to 1/4 size for faster face recognition processing
            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

            # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
            rgb_small_frame = small_frame[:, :, ::-1]

            # Only process every other frame of video to save time
            if process_this_frame:
                # Find all the faces and face encodings in the current frame of video
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                face_names = []
                for face_encoding in face_encodings:
                    # See if the face is a match for the known face(s)
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                    name = "Unknown"

                    face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        name = known_face_names[best_match_index]

                    face_names.append(name)

            process_this_frame = not process_this_frame

            # Display the results
            for (top, right, bottom, left), name in zip(face_locations, face_names):
                # Scale back up face locations since the frame we detected in was scaled to 1/4 size
                top *= 4
                right *= 4
                bottom *= 4
                left *= 4

                # Draw a box around the face
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

                # Draw a label with a name below the face
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

                if (name == "Unknown"):
                    print("Access Denied")
                    to = "zacharyvella@gmail.com"
                    user = "zacharyvella@gmail.com"
                    password = "password"# Hello miss I removed my password for my own private safety

                    server = smtplib.SMTP("smtp.gmail.com", 587)
                    server.starttls()
                    server.login(user, password)
                    server.sendmail(user, to, "Restricted access detected")
                    server.quit()
                    print('Sent email successfully')
                    video_capture.release()
                    break
                else:
                    print("Access Granted")
                    break

            # Display the resulting image
            cv2.imshow('Video', frame)

            # Hit 'q' on the keyboard to quit!
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

            if cv2.getWindowProperty('Video', cv2.WND_PROP_VISIBLE) < 1:
                break

        # Release handle to the webcam
        video_capture.release()
        cv2.destroyAllWindows()


window = Tk()
window.title("Main Menu")
window.geometry('400x300')

label = Label (window, text="                   ").grid(row=1,column=1)

label = Label (window, text="Scan me").grid(row=1,column=6)

label = Label (window, text="Update me").grid(row=1,column=7)

label = Label (window, text="                  ").grid(row=2,column=5)

btn1 = Button(window,text='Click me !!!')
btn1.grid(row=2,column=6)
btn1.config(command=click2)

btn2 = Button(window,text='Click me !!!')
btn2.grid(row=2,column=7)
btn2.config(command=click1)
window.mainloop()

